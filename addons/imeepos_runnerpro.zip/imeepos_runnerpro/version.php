<?php

if(!defined('IN_IA')) {
    exit('Access Denied');
}
if(!defined('EWEI_SHOPV2_VERSION')) {
    define('EWEI_SHOPV2_VERSION', '3.1.5');
}


if(!defined('EWEI_SHOPV2_RELEASE')) {
define('EWEI_SHOPV2_RELEASE', '20171109013721');
}

