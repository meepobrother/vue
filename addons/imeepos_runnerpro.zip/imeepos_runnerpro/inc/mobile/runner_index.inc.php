<?php
global $_W,$_GPC;
define('STATIC_PATH', MODULE_URL."template/mobile/runner/index/");

include $this->template('runner/index/index');
